package com.example.sqflite_database_example

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
